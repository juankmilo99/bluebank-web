export const environment = {
  production: true,
  apiUrl: 'https://bluebank-api.onrender.com',
};
