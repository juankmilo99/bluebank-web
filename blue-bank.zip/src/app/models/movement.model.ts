export interface MovementDto {
  dateTime: string;
  accountNumber: number;
  amount: number;
  type: string;
}
