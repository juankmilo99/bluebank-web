export const environment = {
  production: false,
  apiUrl: 'https://bluebank-api.onrender.com',
};
