export interface BalanceResponse {
  balance: number;
}
