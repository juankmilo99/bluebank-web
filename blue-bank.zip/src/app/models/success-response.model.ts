export interface SuccessResponse {
  success: boolean;
  message: string;
}
